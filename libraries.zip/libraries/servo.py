from machine import Pin, PWM


class Servo:
    def __init__(self, signal: int, freq: int = 50, continuous: bool = False):
        self.signal_pin = signal
        self.servo = PWM(Pin(signal), freq=freq)
        self.continuous = continuous
        self.neutral = 4915  # Center point for continuous servo

    def rotate(self, angle: int):
        """Rotate the servo to a specific angle (standard servo)"""
        if self.continuous:
            raise ValueError("Use set_speed() for continuous servo")
        duty = int(((angle / 180) * 10 + 2.5) / 100 * 1023)
        self.servo.duty(duty)

    def set_speed(self, speed: int):
        """
        Set the speed for continuous servo rotation.
        speed: -100 to 100
               0 = stopped
               positive = clockwise
               negative = counter-clockwise
        """
        if not self.continuous:
            raise ValueError("Use rotate() for standard servo")
        # Normalize speed from -100 to 100 range to -1.0 to 1.0
        normalized_speed = speed / 100.0
        range = 2000
        duty = int(self.neutral + normalized_speed * range)
        self.servo.duty_u16(duty)

    def stop(self):
        """Stop the servo (only for continuous servo)"""
        if self.continuous:
            self.set_speed(0)

    def get_signal_pin(self) -> int:
        # Get the signal pin
        return self.signal_pin